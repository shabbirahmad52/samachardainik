export const baseUrl = "https://backend.samachardainik.com";
