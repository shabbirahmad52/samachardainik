export const data = [
    {
      "id": 2513,
      "title": "प्रदेश",
      "slug": "province",
      "type": "category",
      "data_id": "15",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2514,
      "title": "समाज",
      "slug": "society",
      "type": "category",
      "data_id": "13",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2515,
      "title": "राजनीति",
      "slug": "राजनीति",
      "type": "category",
      "data_id": "9",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2516,
      "title": "विचार/ब्लग",
      "slug": "विचार/ब्लग",
      "type": "category",
      "data_id": "10",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2517,
      "title": "विजनेश",
      "slug": "विजनेश",
      "type": "category",
      "data_id": "2",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2518,
      "title": "दुनियाँ",
      "slug": "दुनियाँ",
      "type": "category",
      "data_id": "11",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2519,
      "title": "जीवनशैली",
      "slug": "जीवनशैली",
      "type": "category",
      "data_id": "13",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2520,
      "title": "रंगशाला",
      "slug": "रंगशाला",
      "type": "category",
      "data_id": "4",
      "parent_id": "0",
      "child": [
        
      ]
    },
    {
      "id": 2512,
      "title": "पर्यटन",
      "slug": "पर्यटन",
      "type": "category",
      "data_id": "8",
      "parent_id": "0",
      "child": [
        
      ]
    }
  ]