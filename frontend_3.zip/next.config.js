module.exports = {
  images: {
    domains: [
      "i0.wp.com",
      "i1.wp.com",
      "i2.wp.com",
      "backend.samachardainik.com",
      "samachardainik.com",
      "merokala.com",
    ],
  },
  env: {
    FB_TOKEN:
      "EAA5nHF6bgegBAMDtfZAGzSvVjTwluLU3xdZCKoc2YUUYEk3foR8FgQ7k3QeJBhrLh1eSFBrSp3YzaQBZAt6YZCxykgl7EHykjuiL7lEUdsrofZBYuN1zCQ25SxBjOWZBUwgMqLmkeU24C1A7CXwxZCKQUGptMf7NZCmtJfJ4NFqWGwZDZD",
    FB_PAGE_ID: "1779405229026684",
    FB_APP_ID: "4054021217944040",
    ONE_SIGNAL_APP_ID: "a4fdf601-a6c8-4dc6-9ceb-36ddd6c3ccdd",
  },
};
